import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-repartidores',
  templateUrl: './repartidores.component.html',
  styleUrls: ['./repartidores.component.scss'],
})
export class RepartidoresComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
