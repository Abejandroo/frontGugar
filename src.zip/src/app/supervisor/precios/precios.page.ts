import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, ModalController, ToastController } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { add, pricetag, createOutline, trashOutline, walletOutline, close } from 'ionicons/icons';
import { AgregarprecioPage } from 'src/app/modal/agregarprecio/agregarprecio.page';
import { EditarprecioPage } from 'src/app/modal/editarprecio/editarprecio.page';
import { PrecioService } from 'src/app/service/precio';
import { AdminNavbarComponent } from "src/app/components/admin-navbar/admin-navbar.component";

@Component({
  selector: 'app-precios',
  templateUrl: './precios.page.html',
  styleUrls: ['./precios.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, AdminNavbarComponent]
})
export class PreciosPage {

  precios: any[] = [];
  cargando: boolean = true;

  constructor(
    private precioService: PrecioService,
    private modalCtrl: ModalController,
    private toastCtrl: ToastController
  ) {
    addIcons({ add, pricetag, createOutline, trashOutline, walletOutline, close });
    this.cargarPrecios();

  }


  cargarPrecios() {
    this.cargando = true;
    this.precioService.obtenerPrecios().subscribe({
      next: (res) => {
        this.precios = res;
        this.cargando = false;
      },
      error: (err) => {
        console.error(err);
        this.cargando = false;
      }
    });
  }
  async abrirModalCrear() {
    const modal = await this.modalCtrl.create({
      component: AgregarprecioPage
    });
    await modal.present();

    const { data } = await modal.onDidDismiss();
    if (data && (data.registrado || data.actualizado)) {
      this.cargarPrecios();
    }
  }

  async abrirModalEditar(precioSeleccionado: any) {
    const modal = await this.modalCtrl.create({
      component: EditarprecioPage,
      componentProps: { precio: precioSeleccionado }
    });
    await modal.present();

    const { data } = await modal.onDidDismiss();

    if (data && (data.registrado || data.actualizado)) {
      this.cargarPrecios();
    }
  }
  confirmarEliminar(precio: any) {
    if (window.confirm(`¿Estás seguro de eliminar "${precio.tipoCompra}"?`)) {
      this.eliminar(precio.id);
    }
  }

  eliminar(id: number) {
    this.cargando = true;

    this.precioService.eliminarPrecio(id).subscribe({
      next: () => {
        this.cargando = false;
        this.mostrarToast('Precio eliminado correctamente', 'success');
        this.cargarPrecios();
      },
      error: (err) => {
        this.cargando = false;
        console.error(err);
        this.mostrarToast('No se pudo eliminar. Verifique que no tenga clientes asignados.', 'danger');
      }
    });
  }

  async mostrarToast(msg: string, color: string) {
    const toast = await this.toastCtrl.create({ message: msg, duration: 2000, color, position: 'bottom' });
    toast.present();
  }
}