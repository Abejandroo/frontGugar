import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AgregarprecioPage } from './agregarprecio.page';

describe('AgregarprecioPage', () => {
  let component: AgregarprecioPage;
  let fixture: ComponentFixture<AgregarprecioPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AgregarprecioPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
