import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EditarprecioPage } from './editarprecio.page';

describe('EditarprecioPage', () => {
  let component: EditarprecioPage;
  let fixture: ComponentFixture<EditarprecioPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(EditarprecioPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
