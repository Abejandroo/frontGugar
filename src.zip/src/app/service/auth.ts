import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Auth {
  private apiUrl = 'https://backgugar-production.up.railway.app';

  constructor(private http: HttpClient) { }

  login(correo: string, contrasena: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/login`, {
      email: correo,
      password: contrasena
    }).pipe(
      tap((res: any) => {
        if (res.user) {
          localStorage.setItem('usuario', JSON.stringify(res.user));
          localStorage.setItem('token', 'sesion-activa'); 
        }
      })
    );
  }
  registrar(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/usuarios`, data);
  }

  logout() {
    localStorage.clear();
  }
  getUsuarios(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/usuarios`);
  }
  actualizarUsuario(id: number, data: any): Observable<any> {
    return this.http.patch(`${this.apiUrl}/usuarios/${id}`, data);
  }
   eliminarUsuario(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/usuarios/${id}`);
  }
  
 
  // GESTIÓN DE RUTAS

  crearRuta(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/rutas`, data);
  }

  obtenerRutas(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/rutas`);
  }

  obtenerRuta(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/rutas/${id}`);
  }
  actualizarRuta(id: number, data: any): Observable<any> {
    return this.http.patch(`${this.apiUrl}/rutas/${id}`, data);
  }
  eliminarRuta(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/rutas/${id}`);
  }
}