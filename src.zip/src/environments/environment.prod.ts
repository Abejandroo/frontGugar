export const environment = {
  production: true,
  apiUrl:'https://backgugar-production.up.railway.app'
};
